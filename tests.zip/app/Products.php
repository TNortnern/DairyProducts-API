<?php

namespace App;

use App\Products;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

// generate a model, controller, factory, and migration by using
// php artisan make:model Products -m -r -f

class Products extends Model
{
    //what items should be mass fillable, add this with every model
    protected $guarded = [];

    public static function getAllProducts(){
        $products = DB::table('products')
        ->join('categories', 'products.id', '=', 'categories.id')->get();
        return $products;
    }
}
